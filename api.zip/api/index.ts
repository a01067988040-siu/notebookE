import { createApiApp } from './_app';

const app = createApiApp();

export default function handler(req: unknown, res: unknown) {
  return app(req as never, res as never);
}
